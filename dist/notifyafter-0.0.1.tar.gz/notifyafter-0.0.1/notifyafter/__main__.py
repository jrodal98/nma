#!/usr/bin/env python3
# Jacob Rodal (https://www.jrodal.dev) (jr6ff@virginia.edu)

from .main import main

if __name__ == "__main__":
    main()
